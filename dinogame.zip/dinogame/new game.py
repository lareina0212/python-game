import turtle
import math
import random
import os
import time
import sys

#set up screen
wn=turtle.Screen()
wn.bgcolor("black")
wn.bgpic("bkg.gif")
wn.tracer(3) # 3 is faster
wn.title("Dino game")

wn.register_shape("sugarman.gif")
wn.register_shape("snowman_left.gif")
wn.register_shape("bomb.gif")
def start_game():
    game_state="game"

#draw border
mypen=turtle.Turtle()
mypen.color("white")
mypen.penup()
mypen.setposition(-300,-300)
mypen.pendown()
mypen.pensize(3)
for side in range(4):
    mypen.forward(600)
    mypen.left(90)
mypen.hideturtle()

#create the score

score=0
high_score=0
lives=6


pen=turtle.Turtle()
pen.shape("square")
pen.color("white")
pen.penup()
pen.goto(-290,310)
pen.hideturtle()
pen.write("Score: {}    Highest Score:{}    Lives:{}".format(score,high_score,lives),align="left", font=("Arial", 14, "normal"))

#create player turtle
player=turtle.Turtle()
player.color("black")
player.shape("turtle")
player.penup()
player.speed(0)


#create bomb
bombs=[]
for _ in range(2):
    bomb = turtle.Turtle()
    #bomb.color("yellow")
    bomb.shape("bomb.gif")
    bomb.penup()
    bomb.speed(0)
    bomb.setposition(random.randint(-300,300),random.randint(-300,300))
    bombs.append(bomb)
    
    

    
#create multi goals
maxGoals=7
goals= []


for count in range(maxGoals):
    goals.append(turtle.Turtle())
    #goals[count].color("grey")
    goals[count].shape("sugarman.gif")
    goals[count].penup()
    goals[count].speed(0)
    goals[count].setposition(random.randint(-300,300),random.randint(-300,300))

       
#set speed variable
speed=1

#define functions
def turnleft():
    player.left(30)
    
def turnright():
    player.right(30)
    
def increasespeed():
    global speed
    speed+=1

def decreasespeed():
    global speed
    speed-=1    

def isCollision(t1,t2):
    d=math.sqrt(math.pow(t1.xcor()-t2.xcor(),2)+math.pow(t1.ycor()-t2.ycor(),2))
    if d<30:
        return True
    else:
        return False 
def gameover():
    
    if lives<=0:
        print("You are out of lives.GAME OVER!!!!!")
        print("Your score is: ",score)
        print("Your highest score is: ",high_score)
        sys.exit()
        game_state="game_over"
        
        

 
    
#set keyboard
turtle.listen()
turtle.onkey(turnleft,"Left")
turtle.onkey(turnright,"Right")
turtle.onkey(increasespeed,"Up")
turtle.onkey(decreasespeed,"Down")


time_limit=150
start_time=time.time()

game_state="game_over"

#create loop
while True:
    player.forward(speed)
    #time code
    elapsed_time=time.time()-start_time
    print(time_limit-int(elapsed_time))
    if elapsed_time>time_limit:
        print("GAME OVER")
        exit()
        
    
    
    #player.forward(speed)
   
    #if game_state=="splash":
        #wn.bgpic("start.gif")
    #elif game_state=="game":
        #wn.bgpic==("bkg.gif")
    

    #boundary checking
    if player.xcor()>300 or player.xcor()<-300:
        player.right(180)
        #os.system("afplay collision.mp3&")

    if player.ycor()>300 or player.ycor()<-300:
        player.right(180)
        #os.system("afplay collision.mp3&")

    

        
    #move the goal
    for count in range(maxGoals):
        goals[count].forward(3)
        
        #boundary checking
        if goals[count].xcor()>290 or goals[count].xcor()<-290:
            goals[count].right(180)
            #os.system("afplay collision.mp3&")

        if goals[count].ycor()>290 or goals[count].ycor()<-290:
            goals[count].right(180)
            #os.system("afplay collision.mp3&")
            
         #collision checking
        if isCollision(player,goals[count]):
             goals[count].setposition(random.randint(-300,300),random.randint(-300,300))
             goals[count].right(random.randint(0,360))
             os.system("afplay popping.mp3&")
             score += 1
             if score > high_score:
                 high_score=score
                 
             pen.clear()
             pen.write("Score: {}    Highest Score:{}    Lives:{}".format(score,high_score,lives),align="left", font=("Arial", 14, "normal"))
             #draw the score   
             #mypen.undo()
             #mypen.penup()
             #mypen.hideturtle()
             #mypen.setposition(-290,310)
             #scorestring="Score: %s" %score
             #mypen.write(scorestring,False, align="left", font=("Arial", 14, "normal"))



        #move the bomb
        for bomb in bombs:
            bomb.forward(3)
        
        #boundary checking
        if bomb.xcor()>290 or bomb.xcor()<-290:
            bomb.right(180)
            #os.system("afplay collision.mp3&")

        if bomb.ycor()>290 or bomb.ycor()<-290:
            bomb.right(180)
            #os.system("afplay collision.mp3&")
          #collision checking
        if isCollision(player,bomb):
             bomb.setposition(random.randint(-300,300),random.randint(-300,300))
             bomb.right(random.randint(0,360))
             os.system("afplay collision.mp3&")
             lives -= 1
             score -= 1
             pen.clear()

             pen.write("Score: {}    Highest Score:{}    Lives:{}".format(score,high_score,lives),align="left", font=("Arial", 14, "normal"))    
             gameover()

             #if game_state=="game_over":
                 #wn.bgpic("gameover.gif")
        #draw the score
             #mypen.undo()
             #mypen.penup()
             #mypen.hideturtle()
             #mypen.setposition(-200,310)
             #scorestring="Lives: %s" %lives
             #mypen.write(scorestring,False, align="left", font=("Arial", 14, "normal"))
             

             
    
